<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'PaymentRequest for Commerce
---------------------------

Initiates a transaction from the Commerce dashboard by requesting the customers to complete an additional payment.

This is a short-term workaround for Commerce\'s lack of initiating back-end transactions. A better implementation is in the works coming to a version of Commerce later in 2020 (you know, assuming we survive the apocalypse). When using this module, please plan to replace it with the core implementation coming soon.
',
    'changelog' => 'Payment Request for Commerce 1.1.0-pl
-------------------------------------
Released on 2020-06-24

- Add email to merchant (configured with commerce_paymentrequest.email_on_complete system setting) when a payment request is paid.

Payment Request for Commerce 1.0.0-pl
-------------------------------------
Released on 2020-06-23

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5c3c05579b304ffa240adb49e4d536d7',
      'native_key' => 'commerce_paymentrequest',
      'filename' => 'modNamespace/64149265e3842c72a54107bf91d99fe0.vehicle',
      'namespace' => 'commerce_paymentrequest',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '14919b129ce211b6d67c6820eb9cb681',
      'native_key' => '14919b129ce211b6d67c6820eb9cb681',
      'filename' => 'xPDOFileVehicle/0b4a1e7db0127d36efed3c283aa1ce86.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e26d1797d73277ab68527b28ef8ca90',
      'native_key' => 'commerce_paymentrequest.pay_resource',
      'filename' => 'modSystemSetting/c91ae1eafe6cc6eee8a4f75ea042cfa5.vehicle',
      'namespace' => 'commerce_paymentrequest',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c88f2a6d415ed5f60b5a65b1b4c0993a',
      'native_key' => 'commerce_paymentrequest.email_on_complete',
      'filename' => 'modSystemSetting/12434afba56825b49ad4e28098c22fff.vehicle',
      'namespace' => 'commerce_paymentrequest',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '994d53bd1ff77b190fbee5edc66414b9',
      'native_key' => NULL,
      'filename' => 'modSnippet/6c7817d971d708c7ad35616f491445f6.vehicle',
      'namespace' => 'commerce_paymentrequest',
    ),
  ),
);