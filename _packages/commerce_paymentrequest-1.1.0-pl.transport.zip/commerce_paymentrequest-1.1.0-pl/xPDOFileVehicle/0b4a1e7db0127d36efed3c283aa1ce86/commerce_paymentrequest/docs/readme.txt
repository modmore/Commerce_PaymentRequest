PaymentRequest for Commerce
---------------------------

Initiates a transaction from the Commerce dashboard by requesting the customers to complete an additional payment.

This is a short-term workaround for Commerce's lack of initiating back-end transactions. A better implementation is in the works coming to a version of Commerce later in 2020 (you know, assuming we survive the apocalypse). When using this module, please plan to replace it with the core implementation coming soon.
