<?php

$xpdo_meta_map = array (
  'comSimpleObject' => 
  array (
    0 => 'prPaymentRequest',
  ),
);