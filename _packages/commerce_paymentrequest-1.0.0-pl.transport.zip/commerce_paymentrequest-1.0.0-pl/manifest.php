<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'PaymentRequest for Commerce
---------------------------

Initiates a transaction from the Commerce dashboard by requesting the customers to complete an additional payment.

This is a short-term workaround for Commerce\'s lack of initiating back-end transactions. A better implementation is in the works coming to a version of Commerce later in 2020 (you know, assuming we survive the apocalypse). When using this module, please plan to replace it with the core implementation coming soon.
',
    'changelog' => 'Payment Request for Commerce 1.0.0-pl
-------------------------------------
Released on 2020-06-23

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c1b7ca54605846e307a9eaa0f1b5b74c',
      'native_key' => 'commerce_paymentrequest',
      'filename' => 'modNamespace/547996a55665ad23c3fbfc070658702b.vehicle',
      'namespace' => 'commerce_paymentrequest',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '55e8a7564c3f80f67d272dfaf0226a67',
      'native_key' => '55e8a7564c3f80f67d272dfaf0226a67',
      'filename' => 'xPDOFileVehicle/be7a9d7f0a001b7f364601e69d13d813.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00fd8285c36ccc69ae0ff0f8d93f98b3',
      'native_key' => 'commerce_paymentrequest.pay_resource',
      'filename' => 'modSystemSetting/603a045b8b03208a4ba4754b452b1695.vehicle',
      'namespace' => 'commerce_paymentrequest',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSnippet',
      'guid' => '46bec2689076169ab927f59ed5e8e5fa',
      'native_key' => NULL,
      'filename' => 'modSnippet/92ea71a1554726193b1217d7f2582542.vehicle',
      'namespace' => 'commerce_paymentrequest',
    ),
  ),
);